/* Local offline chess analysis. No remote services or account required. */
importScripts('../lib/chess.min.js');
const VALUES={p:100,n:320,b:335,r:500,q:900,k:0};
function evaluate(game){
  if(game.in_checkmate())return game.turn()==='w'?-100000:100000;
  if(game.in_draw())return 0;
  const board=game.board();let score=0;
  for(let r=0;r<8;r++)for(let c=0;c<8;c++){
    const p=board[r][c];if(!p)continue;
    const center=(3.5-Math.abs(c-3.5))+(3.5-Math.abs(r-3.5));
    const advancement=p.color==='w'?6-r:r-1;
    const bonus=p.type==='p'?advancement*5+center*2:p.type==='n'||p.type==='b'?center*7:0;
    score+=(p.color==='w'?1:-1)*(VALUES[p.type]+bonus);
  }
  return score;
}
function ordered(game){return game.moves({verbose:true}).sort((a,b)=>
  ((b.captured?VALUES[b.captured]*10-VALUES[b.piece]:0)+(b.promotion?900:0))-
  ((a.captured?VALUES[a.captured]*10-VALUES[a.piece]:0)+(a.promotion?900:0)));
}
function search(game,depth,alpha,beta,deadline){
  if(Date.now()>deadline)throw Error('timeout');
  if(depth===0||game.game_over())return evaluate(game)*(game.turn()==='w'?1:-1);
  let best=-Infinity;
  for(const m of ordered(game)){
    game.move(m);const value=-search(game,depth-1,-beta,-alpha,deadline);game.undo();
    best=Math.max(best,value);alpha=Math.max(alpha,value);if(alpha>=beta)break;
  }
  return best===-Infinity?0:best;
}
function analyze(fen,depth,maxTimeMs){
  const game=new Chess();if(!game.load(fen))throw Error('Invalid board position');
  const moves=ordered(game);if(!moves.length)throw Error('Game has ended; no legal moves');
  const deadline=Date.now()+Math.min(2500,Math.max(250,Number(maxTimeMs)||1000));
  let best=moves[0],score=0,completed=0;
  for(let d=1;d<=Math.min(4,Math.max(1,Number(depth)||3));d++){
    try{
      let top=-Infinity,choice=best;
      const candidates=[best,...moves.filter(m=>m.from!==best.from||m.to!==best.to||m.promotion!==best.promotion)];
      for(const m of candidates){
        if(Date.now()>deadline)throw Error('timeout');
        game.move(m);const value=-search(game,d-1,-Infinity,Infinity,deadline);game.undo();
        if(value>top){top=value;choice=m;}
      }
      best=choice;score=top;completed=d;
    }catch(e){if(e.message!=='timeout')throw e;break;}
  }
  const uci=m=>m.from+m.to+(m.promotion||'');
  return {success:true,analysis:{bestMove:uci(best),ponder:null,evaluation:Math.round(score*(game.turn()==='w'?1:-1)),mate:null,depth:completed||1},meta:{local:true}};
}
self.onmessage=e=>{const {id,fen,depth,maxTimeMs}=e.data;try{self.postMessage({id,success:true,data:analyze(fen,depth,maxTimeMs)});}catch(err){self.postMessage({id,success:false,error:err.message});}};
