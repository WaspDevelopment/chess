/* ChessHelper Free: entirely local, no authentication, payments, or API. */
const defaults={extensionEnabled:true,analysisEnabled:true,depth:3,autoplayEnabled:false,autoplayDelay:1000,autoplayDelayMin:500,autoplayDelayMax:2000,autoplayVariationEnabled:true,antidetectEnabled:false,antidetectIntervalMin:5,antidetectIntervalMax:6};
let engine=null,seq=0;const pending=new Map();
function getEngine(){
 if(!engine){engine=new Worker(chrome.runtime.getURL('background/local-engine.js'));
  engine.onmessage=e=>{const p=pending.get(e.data.id);if(p){pending.delete(e.data.id);p(e.data);}};
  engine.onerror=()=>{for(const resolve of pending.values())resolve({success:false,error:'Local engine failed'});pending.clear();engine.terminate();engine=null;};}
 return engine;
}
function analyze(msg){return new Promise(resolve=>{const id=++seq;pending.set(id,resolve);getEngine().postMessage({id,fen:msg.fen,depth:msg.depth||3,maxTimeMs:msg.maxTimeMs});});}
async function broadcast(message){for(const url of ['*://*.chess.com/*','*://*.lichess.org/*']){const tabs=await chrome.tabs.query({url});for(const tab of tabs)if(tab.id)chrome.tabs.sendMessage(tab.id,message).catch(()=>{});}}
chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
 (async()=>{
  switch(msg.type){
   case 'API_ANALYZE':return await analyze(msg);
   case 'GET_SETTINGS':{const s=await chrome.storage.local.get(defaults);if(sender.tab?.id)chrome.tabs.sendMessage(sender.tab.id,{type:'SETTINGS_RESPONSE',settings:s}).catch(()=>{});return {success:true};}
   case 'GET_GAME_ID':{const k='gameId_'+sender.tab?.id;const old=await chrome.storage.session.get(k);if(!old[k])await chrome.storage.session.set({[k]:crypto.randomUUID()});return {gameId:old[k]||(await chrome.storage.session.get(k))[k]};}
   case 'RESET_GAME_ID':{await chrome.storage.session.remove('gameId_'+sender.tab?.id);return {success:true};}
   case 'GET_AUTH_STATE':return {authenticated:true,profile:{plan:'free',name:'Free Local Edition'},anonymousGamesCount:0};
   case 'FETCH_PROFILE':return {profile:{plan:'free',name:'Free Local Edition'}};
   case 'GET_BASE_URL':return {baseUrl:null};
   case 'GET_SELECTOR_DIAGNOSTICS':return {diagnostics:null};
   case 'GAME_STARTED':case 'GAME_ENDED':case 'DOM_HEALTH_REPORT':case 'SELECTOR_DIAGNOSTICS':case 'TRACK_ANONYMOUS_GAME':return {success:true};
   case 'CLEAR_TOKEN':return {success:true};
   default:return {success:false,error:'This feature is not needed in the free offline edition.'};
  }
 })().then(sendResponse).catch(e=>sendResponse({success:false,error:e.message}));return true;
});
const watched=new Set(Object.keys(defaults));
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'){const settings={};for(const [key,val] of Object.entries(changes))if(watched.has(key))settings[key]=val.newValue;if(Object.keys(settings).length)broadcast({type:'SETTINGS_CHANGED',settings}).catch(()=>{});}});
chrome.runtime.onInstalled.addListener(async()=>{const old=await chrome.storage.local.get(Object.keys(defaults));const updates={};for(const [k,v] of Object.entries(defaults))if(old[k]===undefined)updates[k]=v;updates.depth=3;await chrome.storage.local.set(updates);await chrome.storage.local.remove(['extensionToken','userProfile','lastProfileFetch','anonymousGameIds','anonymousGamesCount']);});
