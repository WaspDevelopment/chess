globalThis._cfg={API_DEPTH:3,RATE_LIMIT_OVERLAY:false};
